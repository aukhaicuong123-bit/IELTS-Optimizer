# HƯỚNG DẪN BUILD UI IELTS OPTIMIZER CHO AI CODING AGENT

## 0. Mục tiêu và các nguyên tắc không được phá vỡ

Hãy coi repo hiện tại là sản phẩm thật đang chạy, không phải dự án demo được phép viết lại tùy ý. Mục tiêu là nâng chất lượng trải nghiệm bằng visual hierarchy, trạng thái học tập rõ ràng và gamification nhẹ nhàng, giữ nguyên nội dung học, logic chấm/lưu kết quả, điều hướng và dữ liệu hiện có.

**Visual direction đã chốt**
- Light theme: nền kem/trắng ấm, sage/mint, forest green/teal, nhấn vàng nhạt và coral chỉ cho trạng thái tương ứng.
- Minh họa watercolor/vector phong cảnh núi, đường mòn, rừng, sách, bản đồ, đèn lồng, mục tiêu, micro; không có hình người, mascot người hoặc avatar người được sinh bằng AI.
- Giao diện trưởng thành, đáng tin, có chất phiêu lưu nhưng vẫn là công cụ học IELTS. Không neon, không dark fantasy, không gamification kiểu game trẻ em.
- Sidebar hiện tại phải giữ nguyên cấu trúc, thứ tự mục, biểu tượng, trạng thái active và hành vi responsive. Không thay sidebar bằng ảnh/collage hay thêm tranh trang trí vào menu.
- Không sử dụng ảnh collage giao diện làm background hoặc nhét ảnh chụp màn hình vào webpage. Agent phải dựng UI bằng React + CSS, dùng ảnh trong `assets/` làm minh họa riêng lẻ.

## 1. Đọc kiến trúc trước khi sửa

Repo: `aukhaicuong123-bit/IELTS-Optimizer`, ứng dụng React + TypeScript + Vite.

Các file quan trọng đã xác minh trong repo:
- `src/App.tsx`: shell ứng dụng, `navGroups`, route state và nhiều view như `Dashboard`, `LearnerProfileCard`, `DashboardTimerCard`, `RecentEvidence`, `Practice`, `SkillPractice`, `Profile`.
- `src/styles.css`: hệ thống CSS lớn, theme, dashboard cards, layout và style của `ForumStudyTree`.
- `src/extra.css`: style bổ sung cho hub và các widget khác; kiểm tra trước khi thêm selector mới để tránh chồng chéo.
- `src/components/ForumStudyTree.tsx`: hành trình gamification 6 cấp bậc và thẻ XP.
- `src/components/ForumVocabularyHub.tsx`: hub từ vựng; từ đã biết lưu trong localStorage với key `ielts-optimizer-vocab-known`.
- `src/components/ForumGrammarHub.tsx`: hub ngữ pháp; kết quả bài tập có thể ghi vào `s.submissions`.
- `src/components/ActivityHeatmapHub.tsx`: heatmap và phân tích hoạt động học.
- `src/ExamLibraryView.tsx`: thư viện/đề thi.
- `src/domain.ts`: học liệu dựa trên evidence, recommendations, timer/session functions và thống kê hoạt động.
- `src/learningEngine.ts`, `src/readingEngine.ts`, `src/storage.ts`, `src/types.ts`: logic học, lỗi sai, dữ liệu lưu và kiểu miền.
- `src/ui-contract.test.ts`: có kiểm tra hợp đồng JSX của recommendation; đừng làm hỏng.

Trước khi code:
1. Đọc toàn bộ component liên quan, không chỉ dựa vào hướng dẫn này.
2. Tìm hết selector liên quan đến các class sắp sửa đổi trong cả `styles.css` và `extra.css`.
3. Xác định đúng nguồn dữ liệu thật cho XP, progress, timer và recommendation.
4. Ghi lại cách chạy test/build hiện tại.
5. Triển khai theo từng phần nhỏ, không thay toàn bộ `App.tsx` hoặc CSS lớn chỉ để đạt một ảnh mẫu.

## 2. Kiến trúc component đích

Tái sử dụng các component sẵn có trước khi tạo component mới. Có thể tách component nhỏ nếu giảm độ phức tạp, nhưng không nhân đôi domain logic.

```text
AppShell (GIỮ SIDEBAR HIỆN TẠI)
├── Dashboard
│   ├── LearningJourney / ForumStudyTree
│   ├── NextStudyMission
│   ├── StudyTimer
│   ├── LearnerProfileSummary
│   ├── SkillProgressSummary
│   ├── RecentLearningEvidence
│   └── ActivityHeatmapHub
├── Reading / Exam Library
├── Listening Practice
├── Writing Lab
├── Speaking Practice
├── Vocabulary Hub
├── Grammar Hub
├── Error Memory / Retest
├── Analytics
└── Profile / Settings
```

`LearningJourney` nên tiếp tục dùng 6 rank hiện có. `NextStudyMission` chỉ là cách trình bày recommendation hiện tại, không được trở thành hệ thống recommendation thứ hai.

Lưu ý kiến trúc: type `Page` hiện có dashboard, practice, errors, record, network, design, profile, listening, writing, speaking, vocabulary, grammar, simulator, question-bank. Chưa có route riêng tên `today` hoặc `journey`. Không tự gắn link tới page không có trong `Page`/router. Có thể hiển thị nhiệm vụ hôm nay ngay trong dashboard; chỉ thêm route mới khi agent đồng thời triển khai route và kiểm thử điều hướng.

## 3. Global layout và thiết kế sidebar

- Giữ nguyên `navGroups` từ `src/App.tsx`: không đổi nhãn, thứ tự hoặc nhóm menu trong phạm vi redesign này.
- Không chèn ảnh núi, avatar, nhân vật hoặc badge to vào sidebar. Chỉ giữ icon Lucide hiện tại và trạng thái active bằng màu nền mềm/viền trái/độ đậm chữ.
- Desktop: sidebar cố định theo cơ chế hiện tại; vùng nội dung dùng `min-width: 0`, `max-width: 100%`, không được làm tăng chiều ngang viewport.
- Mobile: giữ hành vi menu drawer/top bar hiện có; không biến sidebar thành dãy icon không nhãn trừ khi repo đã có chế độ này.
- Focus outline bàn phím phải thấy rõ; active state không chỉ dựa vào màu.
- Trang con dùng spacing, card radius, border, muted text và button hierarchy nhất quán. Dùng token hiện có trong `.workspace-theme` và CSS variable hiện hữu; chỉ ánh xạ thêm từ `docs/design-tokens.css` nếu thực sự cần, tránh tạo theme thứ hai.

## 4. Asset usage và cách tích hợp

Copy thư mục `assets/` trong gói này vào `public/assets/ielts-ui/`. Khi hiển thị tài nguyên với Vite/GitHub Pages, dùng:

```tsx
const UI_ASSET_BASE = `${import.meta.env.BASE_URL}assets/ielts-ui`
// Example:
<img src={`${UI_ASSET_BASE}/sections/listening-headphones.svg`} alt="" aria-hidden="true" />
```

Không dùng `src="/assets/..."` vì GitHub Pages deploy dưới base path `/IELTS-Optimizer/` có thể làm hỏng đường dẫn. Kiểm tra `vite.config.ts` trước khi thay đổi `base`.

### Asset mapping

| Khu vực | File minh họa | Cách dùng |
|---|---|---|
| Dashboard hero | `backgrounds/hero-mountain-with-birds.png` | Background ảnh, `background-size: cover`; thêm overlay kem nhẹ cho khả năng đọc chữ. Không phủ toàn trang bằng ảnh. |
| Journey header | `journey/journey-mountain-path.png` | Lớp cảnh nền bên dưới nội dung journey, `object-fit: cover`, opacity vừa phải. |
| Rank hiện tại | `journey/stage-badge-mountain.png` | Huy hiệu nhỏ ở thẻ rank; để text rank ngoài ảnh, không raster hóa XP vào ảnh. |
| 6 cột mốc | `journey/milestone-backpack.png`, `milestone-lantern.png`, `milestone-signpost.png`, `milestone-treasure-map.png`, `milestone-flag-mountain.png`, `milestone-crowned-summit.png` | Ảnh riêng từng mốc, cùng kích thước vùng chứa và `object-fit: contain`. |
| Reading | `sections/reading-book.svg` | Thẻ chọn kỹ năng, empty illustration nhỏ; không đặt sau đoạn văn/câu hỏi. |
| Thư viện đề thi | `sections/exam-library.svg`, `sections/mock-test-paper.svg` | Hero, collection card hoặc trạng thái trống của `src/ExamLibraryView.tsx`; bộ lọc, tên/mã đề và thông số thi phải là HTML/data thật. |
| Bắt đầu bài thi có giờ | `sections/exam-timer.svg` | Hướng dẫn/intro trước khi bắt đầu; đồng hồ đếm ngược thực tế vẫn là state của simulator. |
| Kết quả đề thi | `sections/exam-results.svg` | Empty/intro hoặc trang trí nhỏ; không thay điểm, band hoặc review câu trả lời thực. |
| Listening | `sections/listening-headphones.svg`, `sections/listening-transcript.svg` | Card kỹ năng hoặc vùng giới thiệu audio/transcript; player thực tế vẫn là control HTML/React. |
| Writing | `sections/writing-notebook.svg`, `sections/writing-feedback.svg` | Header/empty state của Writing Lab và panel giới thiệu feedback; không thay editor/bảng điểm bằng ảnh. |
| Speaking | `sections/speaking-microphone.svg` | Khu vực bắt đầu ghi âm/empty state; waveform nên hiển thị theo âm thanh thật hoặc dạng placeholder có ghi rõ. Không dùng ảnh người. |
| Vocabulary | `sections/vocabulary-flashcards.svg` | Header/empty state; flashcards, nghĩa, phát âm và hành vi lật thẻ phải là HTML thật. |
| Grammar | `sections/grammar-books.svg` | Hình phụ cho hub/chủ đề; rule, example, quiz phải là component thật. |
| Error Memory | `sections/error-review.svg` | Empty state/heading minh họa; trạng thái lỗi thật phải lấy từ ErrorRecord/readingEngine. |
| Analytics | `sections/analytics-chart.svg` | Chỉ dùng làm illustration khi chưa có biểu đồ; chart số liệu phải render từ dữ liệu thật. |
| Timer | `sections/study-timer.svg` | Có thể dùng trong trạng thái nghỉ/giới thiệu; đồng hồ chạy phải là text + state thật. |
| Streak/calendar | `sections/daily-calendar.svg` | Icon minh họa trong thẻ hoạt động; streak và heatmap phải tính từ session thật. |
| Rewards | `sections/achievement-trophy.svg` | Thành tích nhận được thật, không hiện huy hiệu chưa đạt như đã mở khóa. |
| Mission | `sections/task-target.svg` | Thẻ nhiệm vụ gợi ý; task text và CTA lấy từ recommendation. |
| Profile/settings | `sections/profile-settings.svg` | Illustration phi nhân vật. Không generate ảnh avatar người. |
| Empty state | `sections/empty-map.svg` | Chỉ hiện khi chưa có dữ liệu và kèm CTA phù hợp. |

Các hình trang trí dùng `alt="" aria-hidden="true"`. Khi asset đóng vai trò nội dung, cung cấp alt text phù hợp. Chỉ tải asset lớn trên view cần dùng; lazy-load hình dưới màn hình đầu tiên.

## 5. Dashboard: thứ tự ưu tiên và hành vi

### 5.1 Learning Journey
Đặt hành trình lên vị trí nổi bật đầu dashboard, theo ngôn ngữ hình ảnh của bản đồ phiêu lưu đã chốt.
- Badge nhỏ “HÀNH TRÌNH IELTS”; headline dễ đọc; mô tả ngắn, tối đa hai dòng ở desktop.
- Thẻ cấp hiện tại gồm rank, XP tích lũy, XP cần để lên cấp và thanh tiến độ trong cấp hiện tại.
- Dải 6 mốc nằm dưới phần hero; mỗi mốc có ảnh, số, tên, trạng thái (đã qua/hiện tại/chưa mở khóa).
- Hover/focus có border hoặc elevate rất nhẹ; không scale mạnh gây nhảy layout.
- Mobile: stepper chuyển thành danh sách cuộn dọc hoặc carousel truy cập được. Không ép 6 nhãn vào một hàng cực nhỏ.
- Cấp bậc chỉ đổi khi source XP thật thay đổi; không lấy phần trăm course completion thay cho mastery.

### 5.2 Next Study Mission
Tạo thẻ nhiệm vụ rõ ràng sau journey:
- Nhãn “NHIỆM VỤ TIẾP THEO”.
- Tên task do `recommendations(...)` cung cấp; phần giải thích do `rec.reason` cung cấp.
- CTA dẫn đúng tới `rec.page`. Nếu recommendation yêu cầu thiết lập profile, CTA phải mở `profile`; nếu `rec.page === 'dashboard'`, xử lý bằng task pending hoặc skill ưu tiên có thật, không tạo đường dẫn giả.
- Thời lượng/XP dự kiến chỉ hiển thị khi có giá trị thật hoặc rule đã định nghĩa rõ. Không hardcode “+20 XP” làm phần thưởng cho mọi bài.
- Empty state: chưa có profile/attempt thì CTA đưa người dùng tới bước thiết lập/diagnostic đúng.

### 5.3 Timer, profile, evidence, heatmap
- Timer có Start / Pause / Resume / Stop đúng theo state hiện có. Không tạo timer thứ hai chỉ để trông đẹp. Bắt đầu/stop phải tiếp tục ghi phiên học theo `domain.ts` và `storage.ts`.
- Profile giữ target band, level, daily goal, exam date và priority skill. CTA “Cài đặt” giữ navigation hiện tại.
- Recent evidence hiển thị dữ liệu attempt/submission gần nhất và đường dẫn tới Error Memory hoặc Record theo evidence thực tế.
- Heatmap thể hiện thời lượng hoạt động đã ghi nhận hoặc tiến độ mục tiêu thời gian. Nó không đại diện mastery; ngày nghỉ đã lên kế hoạch không coi là thất bại.
- Trên desktop có thể đặt profile và timer cạnh nhau; mobile xếp dọc. Heatmap full-width.

## 6. Gamification: dữ liệu phải thống nhất

Các rank hiện có trong `src/components/ForumStudyTree.tsx`:
1. Người mới
2. Người khám phá
3. Người rèn luyện
4. Kỳ cựu
5. Chuyên gia
6. Bậc thầy IELTS

Cần kiểm tra và refactor nhẹ nếu cần:
- Hiện XP trong `ForumStudyTree` được suy ra từ `knownVocabCount * 15 + completedGrammarCount * 25`. Vocabulary count hiện lấy từ `localStorage` key `ielts-optimizer-vocab-known`; Grammar Hub tính câu đúng trong view, trong khi submissions lưu ở `s.submissions`.
- Đảm bảo dashboard, Vocabulary Hub và Grammar Hub nhận cùng một snapshot XP/rank. Grammar Hub không được truyền `knownVocabCount={0}` làm hành trình tụt XP khi chuyển trang nếu người học có vocab đã biết.
- Trước khi mở rộng điểm cho Reading/Listening/Writing/Speaking, inspect domain/submission schema và các điểm thưởng đã có. Chọn một nguồn XP duy nhất (gamification engine/selectors) và tránh cộng cả completion lẫn submission cho cùng một hành động.
- Tách rõ `XP earned`, `current rank progress` và `course activity completion`; ba giá trị này khác nhau.
- Retest/attempt không được đánh dấu mastery chỉ vì đã bấm hoàn thành; tôn trọng `readingEngine`, Error Memory và quy tắc reliability của evidence.
- Không migrate hay xóa localStorage trong PR redesign. Nếu cần centralize XP, tạo pure selectors và tests cho double-counting, switching routes, empty state và ranh giới rank.


## 6.5 Thư viện đề thi (Exam Library / Mock Tests)

**Route và nguồn dữ liệu hiện có**
- Route trong `Page`: `question-bank`; component: `src/ExamLibraryView.tsx`; danh mục đề: `src/examLibraryData.ts` (`IELTS_EXAM_COLLECTIONS`). Không tạo một trang thư viện song song.
- `ExamLibraryView` đã có `selectedExamId`, `activeExamMode`, bộ lọc module `All | Academic | General Training`, tìm theo tiêu đề/mã đề/volume và bốn simulator Reading/Listening/Writing/Speaking. Tái sử dụng state/navigation hiện hữu thay vì dựng flow mới.
- Nội dung đề hiện tại là **nội dung tự biên soạn mô phỏng format**, không phải đề IELTS chính thức. Giữ tuyên bố này dễ thấy; không tự ghi “Official IELTS” nếu collection metadata không xác nhận.

### Bố cục danh sách đề
1. **Header / intro**: eyebrow “IELTS EXAM LIBRARY · MÔ PHỎNG FORMAT IELTS”, tiêu đề “Thư viện đề luyện tập sát format thi thật”, mô tả ngắn và ghi chú bản quyền/nguồn nội dung. Các chỉ số “số bộ đề” và số câu chỉ lấy từ collection/schema thật.
2. **Filter bar**: tabs Tất cả / IELTS Academic / IELTS General Training theo state hiện tại; ô tìm theo title, code và volume; giữ focus, clear-search dễ dùng và nhãn rõ ràng. Không thêm filter kỹ năng/độ khó giả nếu metadata không có.
3. **Exam collection grid**: mỗi card thể hiện volume, mã đề, tên đề, module, thông tin bốn kỹ năng và cấu trúc/duration được component xác minh, nhãn “Nội dung tự biên soạn”, cùng các CTA riêng cho Full Reading, Full Listening, Writing và Speaking nếu được hỗ trợ. Không buộc người học đọc đoạn mô tả dài lặp lại trên mọi card; đưa specs thành hàng metadata nhỏ có icon.
4. **Visual treatment**: các card nền kem/trắng ấm, viền sage mảnh, teal cho CTA chính, gold làm accent nhỏ. Có thể đặt `exam-library.svg` ở header/empty state; dùng `mock-test-paper.svg` như thumbnail nhẹ; tránh dùng ảnh lớn lặp trên mọi card. Mã đề và metadata là text chọn/copy được, không nằm trong ảnh.
5. **Trạng thái lọc**: số kết quả khớp hiển thị theo `filteredExams.length`; search/filter không có kết quả phải có empty state và nút xóa query/đặt lại filter. Không báo “đang tải” giả cho dữ liệu local tĩnh.

### Luồng bắt đầu bài thi
- Khi chọn Full Reading/Listening/Writing/Speaking, tiếp tục dùng `setSelectedExamId(exam.id)` và `setActiveExamMode(mode)` để chuyển đúng simulator. Không chỉ làm nút trông đẹp mà mất tác dụng.
- Giữ cấu trúc thi theo component hiện tại: Reading gồm 3 passages/40 câu/60 phút; Listening gồm 4 sections/40 câu/30 phút có audio; Writing gồm Task 1 & Task 2; Speaking gồm Part 1/2/3. Chỉ hiển thị số liệu này nếu vẫn đúng với simulator và dataset được dùng.
- Trước khi bắt đầu, nên có thông tin ngắn về kỹ năng, thời gian, số câu và hướng dẫn. Nếu thêm confirm/intro step, phải cho quay lại mà không mất lựa chọn đề; không tạo thêm click không cần thiết cho luồng vốn đã bắt đầu trực tiếp được.
- Khi đang thi: ưu tiên nội dung và thao tác trả lời; thanh trên có tên đề, kỹ năng, timer thực, trạng thái câu hỏi và thoát có xác nhận nếu sẽ mất tiến trình. Phần Reading giữ passage/question split; Listening có player/transcript theo policy hiện có; Writing có editor; Speaking giữ quyền micro/recording state thực.
- Sau khi nộp: hiển thị kết quả theo logic thật, band Reading/Listening tham khảo khi calculator hỗ trợ, answer review và đường quay lại thư viện. Không tự gán XP, điểm chuẩn hoặc tỷ lệ thành công chưa được domain tính.

### Responsive và accessibility
- Desktop: thanh filter linh hoạt phía trên; lưới card 2–3 cột tùy viewport; nội dung chi tiết đề cân bằng và không kéo giãn dòng quá rộng.
- Tablet/mobile: lưới thành 1 cột hoặc 2 cột khi đủ chỗ; filter wrap; search full width; simulator chỉ 1 cột, nút thao tác chạm đủ lớn. Không ép card/bảng qua horizontal scrolling.
- Dùng `<button>` thật cho filter và CTA; `aria-pressed`/`aria-selected` đúng; trạng thái active không dựa chỉ vào màu. Search có accessible label; timer/câu hiện tại đọc được bằng text.
- Hình trang trí: `exam-library.svg`, `mock-test-paper.svg`, `exam-timer.svg`, `exam-results.svg`; ưu tiên SVG nhẹ. Không đưa ảnh người/avatar người vào thư viện hoặc simulator.

### Checklist nghiệm thu riêng
- [ ] Search lọc đúng theo title/code/volume; module filter tương tác chính xác; có empty result recovery.
- [ ] Mỗi CTA mở đúng simulator đúng đề và đúng kỹ năng; thoát quay lại thư viện đúng hành vi.
- [ ] Timer thật, answer state, submit, scoring, answer review và store persistence không bị thay đổi ngoài chủ đích.
- [ ] Cảnh báo “không phải đề chính thức của IELTS” vẫn hiển thị rõ.
- [ ] Các stats/metadata phản ánh collection thực, không hardcode chỉ để khớp thiết kế.
- [ ] Test ở 1440 / 1024 / 768 / 390 / 320px và kiểm tra base path GitHub Pages.

## 7. Reading Practice

### Layout
- Thanh trên: tên bài/passage, band/difficulty badge, timer thật nếu đề có thời gian, progress câu hỏi.
- Desktop: passage và questions thành hai cột cân bằng; passage đọc được, line-height thoáng. Question panel không chen ảnh trang trí vào text.
- Mobile: passage trước, question sau; có nút quay lại passage/đi tới câu hỏi khi cần; không dùng horizontal scroll để xem nội dung chính.
- Câu hiện tại có border/tint. Đáp án đã chọn phân biệt rõ; trạng thái đúng/sai hiển thị sau khi submit, không lộ đáp án khi chưa kiểm tra.
- Previous/Next, đánh số câu, submit/review phải giữ semantics và state của practice hiện có.
- Illustration `reading-book.svg` chỉ đặt ở header/empty state hoặc thẻ chọn bài, không đặt trong passage.

### States bắt buộc
Loading passage; không có passage; câu chưa trả lời; đã chọn; đã submit; kết quả; lỗi tải; đang retest. Nút disabled phải có affordance rõ và trạng thái focus dễ thấy.

## 8. Listening Practice

- Dùng layout gần Reading để giảm tải học UI: danh sách section ở cột trái, nội dung câu hỏi/player ở vùng chính.
- Player có Play/Pause, progress/scrubber, current time/duration, volume nếu hiện có, transcript theo policy hiện tại.
- Không giả lập waveform động nếu không có audio state; nếu dùng ảnh minh họa headphones, đặt bên cạnh header/empty state chứ không phủ vùng player.
- Khi audio đang phát, trạng thái nút và thời gian phải update đồng bộ; khi chuyển section, xác định rõ có reset player hay không theo hành vi hiện tại.
- Hỗ trợ keyboard focus; không chỉ dựa vào màu cho trạng thái audio.

## 9. Writing Lab

- Giữ lựa chọn Task 1/Task 2, loại biểu đồ/chủ đề, khu soạn thảo và phần AI feedback.
- Editor chiếm phần chính; nút lưu nháp, upload/OCR và gửi để nhận feedback nằm trong toolbar có thứ bậc rõ.
- Phần feedback là panel có điểm tổng quan và từng tiêu chí (Task Response/Achievement, Coherence & Cohesion, Lexical Resource, Grammatical Range & Accuracy) nếu dữ liệu trả về hỗ trợ. Không hardcode điểm ví dụ trong UI.
- Biểu đồ minh họa phải là data visualization thật hoặc đề bài asset có sẵn; không tạo số liệu giả để trang trí.
- Loading AI: nút disabled + trạng thái đang phân tích; lỗi API: giữ nguyên draft và hiển thị thông báo có cách retry. Không xóa essay nếu request thất bại.
- `writing-notebook.svg` và `writing-feedback.svg` chỉ là minh họa trang trí/empty state.

## 10. Speaking Practice

- Không có ảnh người, chân dung, avatar người hay nhân vật AI. Dùng `speaking-microphone.svg`, waveform đơn giản và trạng thái ghi âm.
- Topic/Part và prompt nằm cạnh khu ghi âm hoặc trả lời. CTA lớn nhất là bắt đầu/hoàn tất câu trả lời.
- Trạng thái: sẵn sàng, đang ghi, đang xử lý, đã lưu, không có quyền microphone, lỗi. Cần xử lý permission denial và tránh yêu cầu quyền microphone trước khi người dùng bấm bắt đầu.
- Nếu chưa có speech-to-text/AI scoring cho luồng nào đó, thể hiện rõ giới hạn đó, không làm giả feedback.
- Bảo đảm timer ghi âm hiển thị đúng, nút stop có accessible name và focus rõ.

## 11. Vocabulary Hub

- Giữ filters, search, category/topic, flashcard/quiz và thao tác đã biết/cần ôn.
- Flashcard có term, pronunciation/IPA nếu dataset có, part of speech, nghĩa tiếng Việt, ví dụ, nút phát âm và nút “Đã nhớ/Cần ôn”.
- Thông tin chính phải là HTML text, không raster hóa trong hình.
- Khi đánh dấu đã biết, persist qua key hiện có; khi bỏ đánh dấu, XP/rank và counts cần được tính lại. Chặn double count nếu người dùng click nhiều lần.
- Progress theo topic và progress toàn bộ phải phân biệt. Empty search có CTA xóa từ khóa/filter.
- `vocabulary-flashcards.svg` dùng ở empty state/hero nhỏ, không làm các flashcard thật thành ảnh.

## 12. Grammar Hub

- Giữ CEFR/topic filters, search, rule list, expanded rule, ví dụ, mini quiz, trạng thái câu trả lời và lưu submission theo logic hiện có.
- Mỗi rule hiển thị tên, cấp độ, mô tả ngắn, pattern, ví dụ đúng và bài luyện. Không để các card dài bằng nhau bằng cách nhồi text; dùng expand/collapse có kiểm soát.
- Correct/incorrect feedback có icon, text và màu nhưng không dựa chỉ vào xanh/đỏ.
- XP chỉ cộng theo sự kiện completion thật, idempotent khi cùng bài được re-render hoặc người dùng bấm submit lặp.
- `grammar-books.svg` là decoration cho header/empty state; không thay rule cards bằng ảnh.

## 13. Error Memory / Retest

- Tách trạng thái `open`, `resolved`, `insufficient evidence` theo domain thật; không tự đánh dấu lỗi resolved do người dùng mở chi tiết hoặc đã thử retest.
- Cho phép lọc theo kỹ năng/trạng thái/thời gian nếu dữ liệu hỗ trợ. Mỗi row có câu hỏi/skill, ngày, status, lần thử và CTA phù hợp.
- Retest CTA cần hướng tới nhiệm vụ tương đương theo engine hiện có. Khi không có equivalence đủ tin cậy, fail closed và giải thích cần thêm evidence.
- Empty state dùng `error-review.svg`/`empty-map.svg`; không dùng icon cảnh báo đỏ cho mọi lỗi cũ.
- Kiểm tra occurrence-level identity và không gom nhiều occurrence thành một nếu `readingEngine.ts` ghi nhận khác nhau.

## 14. Analytics, study heatmap và streak

- KPI đầu trang ngắn gọn: thời lượng học, số phiên/bài hoàn thành, XP nếu xác minh được; tránh lặp cùng một metric ở nhiều thẻ.
- Heatmap dựa trên session record thật và giải thích rõ đó là hoạt động/thời lượng chứ không phải mastery.
- Biểu đồ kỹ năng cần hiển thị source/period/filter; trạng thái chưa đủ dữ liệu phải dùng empty state thay vì bịa đường biểu đồ.
- Tooltip hoặc accessible text nêu ngày và thời gian thực tế. Màu phải phân biệt được các mức; không chỉ dùng xanh đậm/nhạt nếu người dùng không phân biệt được màu.
- `analytics-chart.svg` chỉ thay cho empty/intro illustration, không thay chart thật.

## 15. Profile / Settings

- Giữ form field và persistence hiện có: target band, current band/level, daily goal, days off, exam date, priority skill cùng các thiết lập đã tồn tại.
- Chia section rõ, label luôn nằm gần input; validate ngay cạnh field và không xóa state khi lỗi.
- Thành tích có thể hiện dưới dạng rank badge/illustration không có nhân vật. Không thêm avatar AI, không dùng ảnh người để lấp chỗ trống.
- Save có trạng thái saving/saved/failure; không báo đã lưu nếu persistence thất bại.

## 16. UI primitives và interaction contract

Tạo/tái sử dụng bộ component thống nhất nếu cần:
- `Button`: primary / secondary / subtle / destructive / icon; size `sm/md/lg`; loading/disabled/focus states.
- `Card`: default / interactive / feature; border, radius, padding thống nhất.
- `Badge`: skill, difficulty, status, rank; dùng cùng scale màu nhưng mỗi trạng thái có nhãn.
- `ProgressBar`: value 0–100, aria-valuenow/min/max, label ở ngoài nếu meaningful.
- `EmptyState`: illustration nhỏ + headline + mô tả + CTA đúng ngữ cảnh.
- `FormField`: label, hint, error, disabled.
- `Tabs/FilterChips`: keyboard accessible, aria-selected đúng.
- `Toast`: giữ cơ chế toast hiện tại, thông báo ngắn và có thể dismiss.

Không bọc mọi thứ trong card. Tạo khoảng nghỉ, tiêu đề nhóm, phân cấp chữ và vùng hành động chính. Hover animation 120–200ms; tuân thủ `prefers-reduced-motion`; không animate layout lớn/đoạn văn.

## 17. Responsive rules

- Desktop từ ~1200px: hero + stats tận dụng chiều rộng nhưng không trải thẻ tới 100% chiều ngang quá mức; giới hạn độ dài đoạn mô tả.
- Tablet: chuyển layout nhiều cột thành 2 cột hoặc 1 cột theo ngưỡng đã có; giữ thứ tự hành động.
- Mobile: 1 cột, CTA full width nếu là hành động chính, card padding nhỏ hơn; tabs có thể wrap hoặc thành select; bảng dữ liệu chuyển thành row cards thay vì horizontal scroll trừ khu vực được thiết kế riêng.
- Không để text, badge hay 6 milestone gây overflow ở 320–375px.
- Test `main { min-width: 0 }`, grid children `min-width: 0`, `max-width: 100%`.

## 18. Accessibility và polish

- Nút có accessible name; ảnh trang trí bị ẩn với screen reader.
- Đảm bảo contrast text/controls; không chỉ dùng màu để chỉ trạng thái đúng/sai.
- Thứ tự focus đi cùng thứ tự thị giác; focus-visible rõ ở sidebar, buttons, tabs, forms và pagination.
- Heading hierarchy tuần tự; tránh dùng `h2` chỉ vì style.
- Respect reduced motion; không dùng confetti/animation cho mỗi thao tác nhỏ.
- Hỗ trợ `prefers-reduced-motion`; animation là bổ sung, không phải tín hiệu duy nhất.

## 19. Cách triển khai theo phase

### Phase A — Baseline and safety
1. Pull latest `main`, tạo branch riêng.
2. Chạy `npm test` và `npm run build` trước thay đổi; ghi nhận lỗi baseline.
3. Đọc CSS cascade và xác định selector dashboard đang bị ghi đè ở `extra.css`/`styles.css`.

### Phase B — Foundations and assets
1. Copy `assets/` trong gói vào `public/assets/ielts-ui/`.
2. Thêm asset helper/constant duy nhất dùng `import.meta.env.BASE_URL`.
3. Map token vào `.workspace-theme` hiện tại.
4. Không thêm thư viện UI mới nếu CSS/React hiện tại đủ đáp ứng.

### Phase C — Dashboard and journey
1. Đặt hành trình lên đầu dashboard.
2. Kiểm tra XP/rank dùng chung giữa dashboard, vocabulary và grammar.
3. Thêm thẻ `Next Study Mission` dùng recommendation sẵn có.
4. Giữ timer, profile, recent evidence, heatmap và persistence.

### Phase D — Skill views and learning hubs
1. Chỉnh layout Reading/Listening.
2. Chỉnh Writing/Speaking và trạng thái audio/AI feedback.
3. Chỉnh Vocabulary/Grammar cards và filter states.
4. Chỉnh Error Memory/Retest, Analytics, Profile/Settings.
5. Asset illustration chỉ thêm sau khi component layout thật hoạt động tốt.

### Phase E — Verification
1. Chạy test và build lại sau mỗi cụm thay đổi lớn.
2. Thêm/cập nhật tests cho XP selectors, route destinations, timer state, persistence, empty states.
3. Kiểm tra GitHub Pages subpath `/IELTS-Optimizer/` và tất cả ảnh asset.
4. Kiểm thử thủ công các chiều rộng 1440, 1024, 768, 390 và 320px.
5. Soát sidebar để bảo đảm không bị thay đổi.

## 20. Definition of Done

- Sidebar còn nguyên, không có hình người ở bất kỳ trang nào.
- Không có ảnh UI mockup bị nhúng như nguyên screenshot.
- Journey và mission hierarchy rõ ở first screen; CTA điều hướng đúng.
- Rank/XP nhất quán khi chuyển Dashboard ↔ Vocabulary ↔ Grammar.
- Timer thực, data persistence, Reading answers, Writing draft/feedback, Speaking state, Error Memory/Retest và heatmap hoạt động như trước.
- Không fake metric, fake completed state hay fake chart.
- Không horizontal overflow ở các viewport nêu trên.
- `npm test` + `npm run build` thành công hoặc mọi lỗi baseline được ghi rõ.
- Báo cáo file đã sửa, lý do sửa, test thực chạy và các rủi ro còn lại.

## 21. Prompt rút gọn để agent bắt đầu

> Hãy đọc toàn bộ `AGENT_BUILD_GUIDE_VI.md` và README trong gói asset này trước khi code. Tự audit code thật trong repo, rồi triển khai theo Phase A–E. Giữ nguyên sidebar, routes, learning logic, persistence và không thêm người/ảnh avatar người. Dựng UI bằng React/CSS; chỉ dùng các ảnh độc lập trong `assets/`, tuyệt đối không nhúng collage screenshot làm UI. Ưu tiên dashboard + journey + mission trước, sau đó lần lượt từng route. Chạy test/build và chỉ báo những gì đã xác minh được.


## 15. Bộ ảnh tham chiếu theo từng màn hình

Mở `references/SCREEN_REFERENCE_INDEX.jpg` để định vị. Mỗi reference độc lập nằm trong `references/screens/` từ `01-dashboard.png` đến `18-empty-loading-responsive.png`. Dùng ảnh để đối chiếu thứ bậc thông tin/composition; tuyệt đối không nhúng ảnh reference vào UI và không coi text/số liệu minh họa trong ảnh là nguồn sự thật. Đặc tả tiếng Việt ở `docs/SCREEN_BY_SCREEN_SPEC_VI.md` ghi yêu cầu, route, state và ràng buộc cho từng màn hình.

Thực hiện theo `docs/IMPLEMENTATION_PLAN_VI.md` và copy prompt từng phase ở `prompts/`. Không làm nhiều phase trong một lần. Trước khi sửa cần chạy test/build baseline; sau mỗi phase phải chạy lại và báo đúng kết quả.
