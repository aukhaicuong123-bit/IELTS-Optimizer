# Changelog — UI Implementation Kit v2

So với gói trước, v2 bổ sung:

- 18 ảnh reference riêng theo màn hình/khu vực, có index contact sheet dễ duyệt.
- Bản đồ repo và route hiện có, để agent không tự tạo route không tồn tại.
- Design system đầy đủ: màu, typography, spacing, state semantics, asset rules và responsive contract.
- Đặc tả screen-by-screen cho Dashboard, Onboarding, Today, Journey, Exam Library/Runner/Results, 4 kỹ năng, Vocabulary, Grammar, Error Memory, Analytics, Profile/Settings, Component Library và Empty/Loading.
- Ma trận state/interactions, kế hoạch phase, QA checklist, no-go list và prompts có thể giao lần lượt.
- Reference và asset manifest nói rõ ảnh nào chỉ để tham khảo, ảnh nào là asset tách rời được phép dùng.

Ảnh reference được crop từ concept board để tiện đối chiếu; không phải screenshot của production, không phải pixel-perfect truth và không được nhúng vào UI. Mọi hành vi/data phải lấy từ code hiện có.
