# IELTS Optimizer — AI UI Implementation Kit v2

Bộ handoff cho coding agent triển khai redesign giao diện thật trên repo React/TypeScript/Vite hiện tại. Gói này kết hợp **ảnh tham chiếu riêng theo từng khu vực**, assets PNG/SVG độc lập, bản đồ repo, design tokens, state matrix, đặc tả luồng và prompt theo phase.

## Bắt đầu từ đâu

1. Đọc `START_HERE_FOR_AGENT.txt`.
2. Đọc `docs/REPO_MAP_VI.md` và `AGENT_BUILD_GUIDE_VI.md`.
3. Mở `references/SCREEN_REFERENCE_INDEX.jpg` để xác định ảnh từng màn hình; mở file ảnh riêng trong `references/screens/` để zoom.
4. Đọc `docs/SCREEN_BY_SCREEN_SPEC_VI.md`, `docs/INTERACTION_STATE_MATRIX_VI.md`, `docs/IMPLEMENTATION_PLAN_VI.md` và `docs/QA_ACCEPTANCE_CHECKLIST_VI.md`.
5. Giao từng prompt trong `prompts/` một phase tại một thời điểm.

## Bộ gói

- `references/screens/`: ảnh tham chiếu crop riêng theo từng screen/khu vực; ảnh chỉ định hướng bố cục, không được nhúng vào website.
- `references/components/`: quick reference cho nhóm component và visual system.
- `references/overview-board-reference.jpg`: board tổng quan để định hướng phong cách.
- `assets/backgrounds/`, `assets/journey/`, `assets/sections/`: asset minh họa tách rời, có tên theo mục đích.
- `docs/`: design system, mapping code, per-screen spec, state matrix, implementation plan, QA và asset integration.
- `prompts/`: prompt có thể copy vào Cline/Codex theo phase.

## Nguyên tắc không thương lượng

- Giữ nguyên sidebar hiện tại: không thay labels, thứ tự, icons hoặc responsive pattern.
- Không có người/khuôn mặt/avatar người/nhân vật người trong ảnh minh họa.
- Không nhúng ảnh mockup/collage thành giao diện. Mọi text, controls, data, chart và interaction phải là component thật.
- Không giả lập XP, band, timer, streak, progress hoặc kết quả thi.
- Không thay đổi persistence key/schema hoặc logic domain nếu không có audit/test và lý do cụ thể.
- Dùng `import.meta.env.BASE_URL` cho asset URL trên GitHub Pages `/IELTS-Optimizer/`.
- Chạy test/build sau mỗi phase; báo cáo chỉ những gì đã thực sự kiểm chứng.

## Cảnh báo về ảnh tham chiếu

Một số ảnh reference là crop từ concept board rộng nên có thể text nhỏ, không chính xác tuyệt đối hoặc có chi tiết minh họa không phù hợp hoàn toàn. Chúng dùng để đọc hierarchy/composition, không phải nguồn dữ liệu, không phải pixel-perfect spec. Đặc tả bằng văn bản và source code hiện có là nguồn sự thật cho behavior/logic.
