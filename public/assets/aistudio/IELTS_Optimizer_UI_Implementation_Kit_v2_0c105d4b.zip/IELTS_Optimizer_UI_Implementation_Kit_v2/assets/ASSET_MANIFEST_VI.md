# Asset Manifest (Vietnamese)

## Backgrounds
- `assets/backgrounds/hero-mountain-with-birds.png` — ảnh nền hero rộng, núi/mây/chim/đường mòn, không có người.

## Journey
- `assets/journey/journey-mountain-path.png` — cảnh núi/đường mòn, dùng dưới nội dung hành trình.
- `assets/journey/stage-badge-mountain.png` — huy hiệu cấp hiện tại.
- `assets/journey/milestone-backpack.png` — mốc Người mới.
- `assets/journey/milestone-lantern.png` — mốc Người khám phá.
- `assets/journey/milestone-signpost.png` — mốc Người rèn luyện.
- `assets/journey/milestone-treasure-map.png` — mốc Kỳ cựu.
- `assets/journey/milestone-flag-mountain.png` — mốc Chuyên gia.
- `assets/journey/milestone-crowned-summit.png` — mốc Bậc thầy IELTS.


## Thư viện đề thi (Exam Library)
- `assets/sections/exam-library.svg` và `.png` — bộ đề nhiều lớp và kính lúp; dùng ở hero/empty state của trang `question-bank`.
- `assets/sections/mock-test-paper.svg` và `.png` — phiếu câu hỏi/ô đáp án; dùng ở thẻ bộ đề hoặc phần giới thiệu trước khi bắt đầu.
- `assets/sections/exam-timer.svg` và `.png` — đồng hồ làm bài và phiếu trả lời; dùng ở phần hướng dẫn thi có thời gian.
- `assets/sections/exam-results.svg` và `.png` — báo cáo kết quả minh họa; chỉ trang trí, không thay bảng điểm hoặc dữ liệu kết quả thực.

## Section illustrations (SVG and PNG equivalents)
- `assets/sections/reading-book.svg` and `.png` — sách mở cho Reading.
- `assets/sections/listening-headphones.svg` and `.png` — tai nghe cho Listening.
- `assets/sections/writing-notebook.svg` and `.png` — sổ tay và bút cho Writing.
- `assets/sections/speaking-microphone.svg` and `.png` — microphone không có nhân vật cho Speaking.
- `assets/sections/vocabulary-flashcards.svg` and `.png` — flashcards cho Vocabulary.
- `assets/sections/grammar-books.svg` and `.png` — sách và ký hiệu cấu trúc cho Grammar.
- `assets/sections/error-review.svg` and `.png` — ghi chú và kính lúp cho Error Memory.
- `assets/sections/analytics-chart.svg` and `.png` — bảng chart cho Analytics/empty state.
- `assets/sections/study-timer.svg` and `.png` — minh họa timer/Pomodoro.
- `assets/sections/daily-calendar.svg` and `.png` — calendar/streak.
- `assets/sections/achievement-trophy.svg` and `.png` — trophy và badge cho reward.
- `assets/sections/empty-map.svg` and `.png` — empty state/trạng thái chưa có dữ liệu.
- `assets/sections/task-target.svg` and `.png` — mục tiêu cho mission card.
- `assets/sections/profile-settings.svg` and `.png` — cài đặt/profile không có ảnh người.
- `assets/sections/listening-transcript.svg` and `.png` — player/transcript illustration.
- `assets/sections/writing-feedback.svg` and `.png` — minh họa feedback; không thay điểm dữ liệu thật.


## UI references (reference-only)
Xem `references/README_VI.md` để mở từng ảnh màn hình riêng; không copy các ảnh reference vào production UI.
