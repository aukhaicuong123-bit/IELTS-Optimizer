# Tích hợp asset an toàn vào repo

## Cài asset

1. Từ thư mục ZIP, copy `assets/` vào `public/assets/ielts-ui/` trong repo nếu dự án chưa có bản được tích hợp.
2. Kiểm tra `public/assets/ielts-journey/` hiện có trước khi copy: repository đã chứa bộ journey; tránh duplicate files cùng mục đích.
3. Ưu tiên dùng tài sản hiện có trong repo khi đã đúng style và path; chỉ copy thêm asset còn thiếu.
4. Không đưa `references/` hay file tài liệu vào `public/` production.

## URL cho Vite + GitHub Pages

```tsx
const UI_ASSET_BASE = `${import.meta.env.BASE_URL}assets/ielts-ui`
const image = `${UI_ASSET_BASE}/sections/reading-book.svg`
```

Không dùng `src="/assets/..."` vì sẽ bỏ qua repo base path. Nếu Vite config đã khai báo base, không sửa base để chữa một URL sai.

## Ví dụ dùng illustration

```tsx
<img
  src={`${UI_ASSET_BASE}/sections/reading-book.svg`}
  alt=""
  aria-hidden="true"
  className="skill-illustration"
/>
```

```css
.skill-illustration {
  width: clamp(56px, 8vw, 96px);
  aspect-ratio: 1;
  object-fit: contain;
  flex: 0 0 auto;
}
```

## Không làm

- Không đặt `references/screens/*.png` vào UI thành ảnh nền.
- Không nhúng cả mockup vào iframe/canvas để giả vờ hoàn thành thiết kế.
- Không raster hóa text, buttons, XP, question data hoặc chart values.
- Không dùng asset người/avatar người; ưu tiên landscape, book, map, lantern, headphones, microphone, target và icons.
- Không đặt ảnh lớn sau nội dung câu hỏi hoặc editor làm giảm độ tương phản.
