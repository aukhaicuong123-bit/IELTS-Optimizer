# Design System — IELTS Optimizer

## Design principles

1. **Journey-first, study-action-second:** người học thấy mình đang ở đâu, điều gì tiếp theo và có thể bắt đầu ngay.
2. **Pastel adventure, not children's game:** xanh mint/sage, kem, xanh rừng và điểm vàng ấm; tránh neon, dark fantasy, nhân vật người và ảnh stock.
3. **Real learning evidence:** XP, rank, streak, heatmap, band, progress và feedback phải phản ánh dữ liệu thật.
4. **Sidebar is frozen:** giữ nguyên cấu trúc, thứ tự, icon, label và hành vi responsive hiện tại.
5. **Illustration never carries data:** không raster hóa chữ, rank, XP, câu hỏi, band hay tiến độ vào ảnh; render bằng HTML/data thật.
6. **Build reusable UI:** cùng một button/card/progress/filter pattern phải có component/token dùng chung, không tạo page-specific inline styles không cần thiết.

## Token gợi ý

Ánh xạ token này vào theme hiện tại; không tạo theme thứ hai và không xóa CSS variables hiện hữu trước khi tìm usage.

| Token | Giá trị | Công dụng |
|---|---|---|
| `--journey-forest` | `#075D52` | Primary CTA, current milestone |
| `--journey-forest-hover` | `#064A42` | Hover/focus nền đậm |
| `--journey-mint` | `#DFF2E7` | Surface nhấn nhẹ |
| `--journey-sage` | `#EDF6EF` | Page background phụ |
| `--journey-cream` | `#FFFEFA` | Card nền |
| `--journey-border` | `#C8DFCF` | Border mềm |
| `--journey-text` | `#173D36` | Text chính |
| `--journey-muted` | `#5D766D` | Text phụ |
| `--journey-gold` | `#F4C56A` | Reward/XP, dùng tiết chế |
| `--journey-success` | `#26865C` | Success có text/label đi kèm |
| `--journey-warning` | `#B7791F` | Cảnh báo nhẹ |
| `--journey-error` | `#C94C4C` | Lỗi cần chú ý |

## Typography

- Ưu tiên font hiện có trong repo (`DM Sans` và `Space Grotesk`) để tránh tải thêm font vô ích.
- Heading trang: 28–36 px desktop, 24–28 px mobile; title card 16–22 px; body 13–15 px; helper 11–12 px.
- Giới hạn line length khoảng 60–80 ký tự với phần giải thích dài; paragraph line-height 1.5–1.7.
- Số liệu quan trọng (XP, phút, phần trăm) dùng tabular numbers nếu font hỗ trợ.

## Spacing & shapes

- Dùng scale 4/8/12/16/20/24/32 px.
- Card radius 12–20 px; pill radius 999 px; control radius 8–12 px.
- Border 1 px, shadow nhẹ, tránh nhiều lớp shadow/glass cùng lúc.
- Page gap 16–24 px; card padding thường 16–24 px; trên mobile giảm còn 14–18 px.

## Buttons

- Primary: nền forest, chữ trắng, một nút primary nổi bật nhất mỗi card.
- Secondary: nền cream/mint, border; dùng cho hành động phụ.
- Ghost: cho action cấp ba và nav nội bộ.
- Disabled có opacity + cursor + giải thích khi lý do không hiển nhiên.
- Focus ring rõ, không chỉ đổi màu background.

## Gamification semantics

- `Current`: forest fill, rõ label và tiến độ.
- `Completed`: mint tint/check icon + text “Đã hoàn thành”.
- `Locked/Future`: nền trung tính, opacity vừa phải, không làm text quá nhạt.
- XP reward: hiển thị lý do và sự kiện được thưởng; chống cộng hai lần cho cùng completion.
- Heatmap màu đậm biểu diễn phút học/tiến độ mục tiêu thời gian, không biểu diễn mastery.
- Planned rest day không bị tô như thất bại.

## Illustration rules

- Không người, không khuôn mặt, không mascot người hoặc avatar người sinh bằng AI.
- Cho phép cảnh núi, rừng, hồ, mây, chim, ba lô, đèn lồng, bản đồ, biển chỉ đường, sách, tai nghe, micro, target, cây.
- Hero background được đặt `background-size: cover` nhưng phải giữ chữ đủ tương phản với overlay/scrim.
- Các milestone dùng vùng chứa cùng aspect ratio; `object-fit: contain`.
- SVG ưu tiên cho icon/illustration nhỏ; PNG cho watercolor/scene lớn.
- Mỗi ảnh decorative dùng `alt="" aria-hidden="true"`; hình thông tin phải có alt có ý nghĩa.

## Responsive contract

- Test 1440, 1024, 768, 390, 320 px.
- `min-width: 0` cho grid/flex children; không tạo overflow-x toàn trang.
- Sidebar phải giữ hành vi hiện tại; không thêm hình vào nav.
- Chỉ giảm số cột và chuyển thứ tự, không giấu CTA quan trọng trên mobile.
- `prefers-reduced-motion` giảm/tắt animation; `prefers-color-scheme` không tự ép theme nếu app đang có preference riêng.
