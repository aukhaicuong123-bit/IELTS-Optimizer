# ĐẶC TẢ TRIỂN KHAI UI — THƯ VIỆN ĐỀ THI IELTS OPTIMIZER

## Phạm vi
Tài liệu này mở rộng `AGENT_BUILD_GUIDE_VI.md`, không thay thế nó. Tích hợp trực tiếp vào `src/ExamLibraryView.tsx` và các CSS/test liên quan; giữ route `question-bank`, sidebar hiện tại, collection dữ liệu và bốn simulator sẵn có. Không tạo ảnh screenshot giả làm website.

## Mục tiêu trải nghiệm
Người học phải trả lời được trong vài giây: có những bộ đề nào, bộ đề này gồm gì, mình có thể làm kỹ năng nào, và bấm đâu để bắt đầu. Visual direction giữ đồng bộ với dashboard: nền cream, sage/mint, forest green/teal, viền mảnh, khoảng trắng tốt, minh họa watercolor nhỏ; tuyệt đối không thêm nhân vật/người.

## Màn hình danh mục đề

### A. Header
- Eyebrow: `IELTS EXAM LIBRARY · MÔ PHỎNG FORMAT IELTS`.
- H1: `Thư viện đề luyện tập sát format thi thật`.
- Đoạn mô tả ngắn nêu Reading, Listening, Writing, Speaking và lưu ý bộ đề là nội dung tự biên soạn, không phải đề chính thức của IELTS.
- Chỉ số số bộ đề và số câu hỏi phải tính từ `IELTS_EXAM_COLLECTIONS` / schema có thật.
- Asset: `assets/sections/exam-library.svg`, giới hạn khoảng 120–180px ở desktop, không để artwork chiếm mất diện tích của tiêu đề.

### B. Thanh tìm kiếm và bộ lọc
- Module filter: `Tất cả các bộ đề`, `IELTS Academic`, `IELTS General Training`. Giữ enum hiện có `All | Academic | General Training`.
- Search: placeholder `Tìm kiếm đề thi, mã đề...`; lọc theo `title`, `code`, `volume` như logic hiện tại.
- Hiển thị `N bộ đề` theo `filteredExams.length`; không đưa số này vào hero cố định.
- Clear search/filter có thể là nút icon nhỏ có accessible label; không thêm bộ lọc kỹ năng/độ khó nếu source chưa có các trường này.

### C. Thẻ bộ đề
Mỗi card nên có thứ bậc sau:
1. Metadata: `volume` và `code` dạng badge.
2. Tiêu đề đề.
3. Bốn hàng specs gọn: Listening, Reading, Writing, Speaking; icon Lucide nhỏ, số câu/thời gian lấy từ schema/simulator khi có thể, không lặp lại đoạn văn giải thích của hero.
4. Source badge: `Nội dung tự biên soạn` và `Mô phỏng thi trên máy tính`. Giữ note “Không phải đề chính thức của IELTS” ở header; không gắn nhãn Official giả.
5. CTA theo kỹ năng: `Full Reading (40 câu)`, `Full Listening`, `Writing`, `Speaking` nếu bốn luồng đều có trong simulator. Nút phải tiếp tục gọi đúng callback hiện tại và set `selectedExamId` + `activeExamMode`.

Cards dùng nền `#fffefa` hoặc token surface hiện có, border sage, radius 14–18px, padding 18–24px. Dùng `mock-test-paper.svg` làm artwork nhỏ trên một vài card/hero nếu cần, nhưng không cần lặp artwork trên mọi card. CTA chính dùng teal; secondary/metadata không cạnh tranh thị giác.

### D. Trạng thái
- Loading: chỉ sử dụng nếu thực sự có async fetch; với collection local import, không thêm spinner giả.
- Empty search/filter: “Không tìm thấy bộ đề phù hợp”, câu gợi ý ngắn và `Xóa bộ lọc`. Dùng `empty-map.svg` hoặc `exam-library.svg` với kích thước khiêm tốn.
- Selected/hover/focus: border/background nhẹ; focus-visible rõ.
- Error state nếu nguồn collection hỏng: thông báo có thể hành động, không crash cả route.

## Simulator và luồng làm bài
- Giữ nguyên các branch `activeExamMode === 'reading' | 'listening' | 'writing' | 'speaking'` và các component simulator đang có.
- Trước khi code, đọc từng simulator để biết trạng thái thực; không refactor logic chấm điểm để phục vụ giao diện.
- Reading: passage/question, câu hiện tại, chọn đáp án, điều hướng câu, nộp bài, kết quả và review.
- Listening: player/audio state, câu hỏi, current time/duration, transcript theo hành vi hiện có. Không giả lập waveform/audio.
- Writing: Task 1/2, prompt/chart thật, editor, lưu nháp, submit và feedback; giữ nội dung khi request lỗi.
- Speaking: Part 1/2/3, prompt, chuẩn bị/ghi âm/stop state, permission error. Không dùng hình người.
- Dùng `exam-timer.svg` chỉ làm minh họa trước bài thi/empty state; timer đang chạy phải render bằng text/state thực. `exam-results.svg` chỉ trang trí; điểm/band/review phải xuất phát từ logic chấm thực tế.
- Nếu thoát bài có nguy cơ mất câu trả lời thì cảnh báo trước; nếu simulator hiện tại đã tự lưu tiến độ, không thêm confirm modal thừa.

## Responsive
- >=1200px: filter bar một hàng khi vừa; grid 2–3 cột card theo không gian nội dung.
- 768–1199px: grid 2 cột nếu card còn đọc được; filter cho wrap.
- <=767px: search full-width, filter wrap hoặc dạng chips; cards 1 cột; simulator 1 cột; CTA chính full-width.
- 320–390px: không tràn mã đề, nút, badges; `min-width:0` cho grid children; không dùng overflow-x để che lỗi layout.

## Source of truth / data integrity
- Collection source: `IELTS_EXAM_COLLECTIONS` trong `src/examLibraryData.ts`.
- Module filter/search state hiện ở `ExamLibraryView`. Duy trì nó hoặc refactor thành hook nhỏ chỉ khi có test tương đương.
- Không hardcode `IELTS_EXAM_COLLECTIONS.length * 80` nếu số câu thực tế không bảo đảm; tính stats từ schema hoặc trình bày các cấu trúc format như mô tả chung được verify.
- Dữ liệu đang tự biên soạn phải được mô tả trung thực. Không gọi là nguồn chính thức.
- Không cấp XP giả chỉ vì mở đề; nếu app có scoring/reward event thì tái sử dụng đúng event hiện có và test chống double count.

## Tests / manual verification
- [ ] Academic/General Training/All filter works.
- [ ] Search matches title, code, and volume; clearing search restores results.
- [ ] Every exam card shows real volume/code/title and honest source note.
- [ ] Reading/Listening/Writing/Speaking CTAs open the selected exam and correct simulator mode.
- [ ] Leaving each simulator returns to the library correctly.
- [ ] Timer, audio, answers, draft, submit, scoring and evidence review remain functional.
- [ ] Empty results are understandable and can be recovered from.
- [ ] Sidebar unchanged; no person imagery; no horizontal overflow at 1440/1024/768/390/320px.
- [ ] `npm test` and `npm run build` pass or baseline failures are documented.
