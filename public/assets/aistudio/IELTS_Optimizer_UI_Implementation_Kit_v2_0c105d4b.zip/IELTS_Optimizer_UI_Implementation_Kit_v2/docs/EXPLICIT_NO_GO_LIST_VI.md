# Những điều agent tuyệt đối không được tự ý làm

- Không thay sidebar, đổi thứ tự/nhãn/icon hoặc thêm ảnh trang trí vào sidebar.
- Không tạo collage/mockup thành một ảnh nền trong DOM sản phẩm.
- Không chèn người, chân dung, ảnh profile người AI, mascot người.
- Không hardcode XP, rank, band score, streak, heatmap values, recommendation, test stats hoặc fake completion.
- Không thêm route và CTA đến page không tồn tại.
- Không xóa key localStorage hoặc đổi Store schema mà không migration và tests.
- Không sửa engine để dễ đạt UI mong muốn; UI phải thích ứng với domain logic.
- Không làm lại nguyên `App.tsx` hoặc append CSS vô hạn nếu có thể chỉnh component/selector hẹp.
- Không đánh dấu lỗi resolved khi chưa có evidence tương đương hợp lệ.
- Không gửi API khi thiếu consent/interaction phù hợp; giữ draft khi lỗi.
- Không tuyên bố build/test pass nếu chưa chạy.
