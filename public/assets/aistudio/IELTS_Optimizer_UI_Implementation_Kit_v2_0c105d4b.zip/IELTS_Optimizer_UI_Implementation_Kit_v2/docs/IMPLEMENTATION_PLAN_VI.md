# Plan triển khai theo phase

Không giao agent thay toàn bộ trang cùng lúc. Mỗi phase phải test/build, review diff và chỉ đi tiếp khi pass.

## Phase 0 — Audit / baseline

- Xác nhận branch/worktree sạch; không overwrite thay đổi user chưa commit.
- Chạy `npm test`, `npm run build`; ghi lại baseline và lỗi có sẵn.
- Audit routes, CSS selectors, domain data sources, assets/base path.
- Kết quả bắt buộc: audit file map, rủi ro, plan file-level. Chưa đổi UI ở phase này.

## Phase 1 — Tokens và shared component polish

- Ánh xạ token từ `docs/DESIGN_SYSTEM_VI.md` vào theme hiện tại.
- Chuẩn hóa các shared button/card/progress/chip/form/focus trong phạm vi selector nhỏ.
- Không xóa/đổi tên class rộng như `.panel`, `main`, `header`, `nav` nếu chưa biết toàn bộ nơi dùng.
- QA: không thay đổi layout/logic các trang ngoài dự kiến; test/build.

## Phase 2 — Dashboard + Journey

- Reuse `ForumStudyTree`, `DashboardTimerCard`, `LearnerProfileCard`, `RecentEvidence`, `ActivityHeatmapHub` và recommendation engine.
- Dashboard hierarchy theo screen spec: journey, mission, timer/today, skills/evidence, heatmap.
- Sidebar giữ nguyên tuyệt đối. Không chèn người.
- Audit XP source và rank consistency giữa dashboard/vocab/grammar; không invent state/metrics.
- QA desktop/mobile, timer start/pause/resume/stop, heatmap update.

## Phase 3 — Thư viện đề thi + simulator

- `src/ExamLibraryView.tsx`; route `question-bank`.
- Redesign collection library, filter/search, cards, no-results, intro/runner/result states bằng component thật.
- Giữ mode Reading/Listening/Writing/Speaking, timer, answer state, submission, scoring, evidence review và disclaimer.
- QA: bắt đầu đúng đề/kỹ năng; back/exit; state không rơi; GitHub Pages base path.

## Phase 4 — Skill practice

- Lần lượt Reading, Listening, Writing, Speaking; mỗi route riêng một PR/change batch.
- Dùng cùng card/type/spacing; không chuyển câu hỏi, transcript, editor thành ảnh.
- Kiểm thử keyboard, audio/mic permissions, editor persistence, result feedback.

## Phase 5 — Vocabulary + Grammar + Error Memory

- Giữ cấu trúc dữ liệu và key localStorage; kiểm tra XP chống duplicate.
- Error status và retest dựa trên engine/evidence; không làm lỏng equivalence requirement.
- QA multi-occurrence, retest correct/wrong, reload/navigate persistence.

## Phase 6 — Analytics + Profile + states + responsive

- Rà chart/heatmap/metrics, profile fields, save/reset dialogs, loading/empty/error/success.
- Kiểm tra lại tất cả breakpoint.
- Chạy full test/build, review diff cuối, smoke test qua từng route.

## Phase completion output

Agent phải báo: các file sửa, quyết định UI quan trọng, test command đã chạy và exit code, ảnh/screenshots nếu có, bug tồn đọng, hành vi chưa thể verify. Không được ghi “tests passed” khi không thực sự chạy.
