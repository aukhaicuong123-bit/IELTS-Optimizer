# Ma trận tương tác và trạng thái

| Thành phần | Default | Loading | Empty | Error | Success | Điều cần xác minh |
|---|---|---|---|---|---|---|
| Journey/rank | Rank hiện tại từ dữ liệu | Skeleton chỉ khi rank load async | Có rank mặc định hợp lệ hoặc hướng dẫn | Không nhận XP state | Rank cập nhật sau event hợp lệ | XP không cộng trùng; rank không reset khi navigate |
| Next mission | Recommendation thật | N/A nếu sync | Gợi ý thiết lập hồ sơ/hành động có nguồn | Fallback có thể hiểu | Click mở đúng route | Không có `page` ma |
| Timer | Idle | N/A | N/A | Recover nếu store sai | Session persist sau stop | Không double-count running elapsed |
| Search/filter | Dataset mặc định | Nếu dataset async | Không có kết quả | Có lỗi tải | Reset lọc được | Search title/code/volume, keyboard |
| Exam runner | Câu hiện tại | Load section | Không có câu thì giải thích | Audio/data error | Submit kết quả thật | timer/answers/submit/review/exit |
| Reading answer | Unanswered | Passage load | No passage | Invalid question data | Feedback sau submit | Không reveal đáp án trước submit |
| Listening player | Ready | Audio loading | No audio | Playback failed/permission | Play/pause/time sync | Section transitions, transcript rule |
| Writing editor | Draft | Feedback generating | Blank draft guidance | API/OCR failed, draft kept | Feedback result saved | No accidental text loss |
| Speaking | Ready | Recording processing | Unsupported mic path | Permission denied | Response saved | Mic only after user intent |
| Vocabulary | Current word | Audio loading | Filter no results | Audio/storage error | Word marked known | localStorage key and idempotent XP |
| Grammar | Rule collapsed/open | N/A | No rule for filter | Invalid item | Submission saved | completed count uses authoritative source |
| Error Memory | Open/resolved | Retest task load | No errors | Equivalence uncertain | Evidence resolves valid occurrence | status != mastery; occurrence identity |
| Heatmap | Recorded activity | Only if async | No sessions | Invalid records | New session appears | minutes/streak/rest-day semantics |
| Profile/settings | Current values | Saving | Optional values unset | Validation/store failure | Save confirmation | no reset without confirmation |
| Toast/modal | Hidden | N/A | N/A | Error toast actionable | Success toast accurate | focus management, dismissal |

## Accessibility minimum

- All actions are real `<button>` or native form controls.
- Search has associated label or accessible name.
- Tabs and filters expose selected state (`aria-selected`, `aria-pressed`) correctly.
- Focus visible; focus trap and return focus for modal; no keyboard trap elsewhere.
- Status isn't communicated using color alone.
- Respect reduced motion; avoid flashing and endless decorative animation.
- Icons accompanying text can be decorative; icon-only buttons need `aria-label`.
