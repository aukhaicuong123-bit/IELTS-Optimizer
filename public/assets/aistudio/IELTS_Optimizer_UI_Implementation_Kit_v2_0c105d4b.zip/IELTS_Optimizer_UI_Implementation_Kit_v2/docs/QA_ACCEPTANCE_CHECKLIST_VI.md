# Checklist nghiệm thu cuối

## Build / repository
- [ ] `git status` không làm mất thay đổi người dùng.
- [ ] `npm test` pass hoặc regression mới được phân biệt rõ với lỗi baseline.
- [ ] `npm run build` pass.
- [ ] Không tạo dependency mới nếu CSS/component hiện có đủ.
- [ ] Không thêm ảnh screenshot/collage vào DOM sản phẩm.
- [ ] Không có asset URL tuyệt đối làm hỏng `/IELTS-Optimizer/`.

## Navigation
- [ ] Sidebar, thứ tự mục, nhãn, icon và mobile behavior giữ như ban đầu.
- [ ] Mọi CTA điều hướng đúng `Page`; không route mồ côi.
- [ ] Back/exit từ simulator trở về màn hình mong đợi.

## Gamification / learning integrity
- [ ] XP chỉ cộng từ action thực và không cộng hai lần.
- [ ] Rank/XP nhất quán khi qua lại Dashboard, Vocabulary, Grammar.
- [ ] 6 rank hiển thị đúng tên/threshold theo quyết định trong code.
- [ ] Streak tính bằng logic session hiện tại.
- [ ] Heatmap intensity phản ánh thời gian/goal, không giả vờ là mastery.
- [ ] Planned rest days không bị xem như failure.
- [ ] Recommendation không bị nhân đôi hoặc hardcode.

## Study tools
- [ ] Reading answer, previous/next, submit/review và retest không đổi.
- [ ] Listening playback/time/section/transcript chính xác.
- [ ] Writing draft không mất khi lỗi API/OCR.
- [ ] Speaking xử lý mic permission và unsupported browser.
- [ ] Vocabulary known words persist qua reload; remove-known cập nhật đúng.
- [ ] Grammar completion và error state persist theo quy tắc hiện tại.
- [ ] Error Memory giữ occurrence identity/evidence requirements.

## Exam Library
- [ ] Search theo title/code/volume.
- [ ] Academic/General Training filter.
- [ ] CTA mở đúng exam và skill.
- [ ] Timer, answers, submit, score, review và return path không hỏng.
- [ ] Disclaimer “không phải đề chính thức của IELTS” nhìn thấy được.
- [ ] Stats dựa trên collections thật; không có số demo giả.

## Visual / responsive
- [ ] 1440 px desktop.
- [ ] 1024 px laptop/tablet landscape.
- [ ] 768 px tablet portrait.
- [ ] 390 px mobile.
- [ ] 320 px narrow mobile.
- [ ] Không horizontal overflow, clipped CTA hay text chồng lấn.
- [ ] Contrast/focus visible, keyboard operation, reduced motion.
- [ ] Không có người, khuôn mặt, avatar người AI hoặc nhân vật người trong minh họa.
- [ ] Empty/loading/error/success state đều có thông điệp và hành động phù hợp.
