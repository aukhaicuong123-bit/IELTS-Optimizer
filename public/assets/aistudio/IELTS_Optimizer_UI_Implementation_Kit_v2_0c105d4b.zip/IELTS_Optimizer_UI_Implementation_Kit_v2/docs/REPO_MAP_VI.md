# Bản đồ repo hiện tại và điểm tích hợp

Đọc file thật trong repo trước khi sửa; tài liệu này là bản định hướng dựa trên cấu trúc đã kiểm tra, không thay thế việc kiểm tra branch hiện tại.

## Stack và entry points

- `src/main.tsx`: React entry.
- `src/App.tsx`: `navGroups`, route state theo `Page`, app shell, dashboard, learner profile, timer, recent evidence và phần lớn view nội bộ.
- `src/styles.css`: global theme, cards, dashboard, timer, profile, evidence, nhiều responsive rules.
- `src/extra.css`: style bổ sung cho topic hubs, widgets, audio/writing components; phải rà selector trùng.
- `src/types.ts`: type `Page`, `Store`, `Profile`, `Attempt`, `StudySession`, `SkillSubmission`.
- `src/domain.ts`: date/minutes/streak, recommendation engine, score attempt, active-session snapshot, error merge.
- `src/storage.ts`: load/clear/persistence store hiện tại.
- `src/readingEngine.ts`: derive reading states, target/retest và difficulty evidence.
- `src/components/ForumStudyTree.tsx`: 6 cấp bậc gamification dùng trên hub; hiện XP được suy ra từ số từ biết và số grammar hoàn thành truyền vào component.
- `src/components/ForumVocabularyHub.tsx`: Vocabulary Hub; trạng thái từ đã biết dùng key localStorage `ielts-optimizer-vocab-known`.
- `src/components/ForumGrammarHub.tsx`: Grammar Hub; quiz, errors và submission có state/persistence riêng cần audit.
- `src/components/ActivityHeatmapHub.tsx`: heatmap/analytics hoạt động học.
- `src/ExamLibraryView.tsx`: thư viện đề và simulator; component lớn, chứa filter/search, exam mode và luồng thi.
- `src/examLibraryData.ts`: collections và calculator band Reading/Listening.
- `src/extra.css`, `src/styles.css`: không gom tất cả CSS vào một file mới mà chưa kiểm tra cascade.

## Routes hiện có (type `Page`)

`dashboard`, `practice`, `errors`, `record`, `network`, `design`, `profile`, `listening`, `writing`, `speaking`, `vocabulary`, `grammar`, `simulator`, `question-bank`.

Không có route riêng `today`, `journey`, `onboarding`, `analytics`, `settings` trong type hiện được kiểm tra. Các hình reference này có thể mô tả block hoặc trạng thái trong màn hình hiện hữu; không tạo link tới route không tồn tại. Nếu cần tách route thì phải cập nhật type/router và viết test rõ ràng.

## Các ràng buộc dữ liệu quan trọng

1. `s.sessions` là nguồn dữ liệu hoạt động học đã lưu; timer đang chạy cần cộng elapsed hiện tại đúng một lần.
2. Heatmap là thời gian/hoạt động được ghi nhận, không phải độ thành thạo.
3. Recommendation lấy từ `recommendations(profile, attempts, errors, plan, states)`; không viết recommendation engine thứ hai trong UI.
4. Rank/XP đang có thể dùng dữ liệu Vocabulary và Grammar ở nhiều component. Phải audit nguồn XP, chống cộng trùng, chống reset khi chuyển trang, không tự chọn nguồn dữ liệu theo mockup.
5. `question-bank` render `ExamLibraryView`; không thay simulator bằng HTML tĩnh. Giữ search, Academic/General Training, mode, timer, answer state, submit, scoring và result review.
6. Giữ disclaimer đề là nội dung tự biên soạn theo format IELTS, không phải đề chính thức.
7. GitHub Pages có base path `/IELTS-Optimizer/`. Asset public phải dùng `${import.meta.env.BASE_URL}assets/ielts-ui/...` hoặc quy ước đã có của repo.

## Quy trình bắt buộc trước khi sửa

- Kiểm tra `git status`, branch và log; không overwrite thay đổi chưa commit của người dùng.
- Chạy `npm test` và `npm run build` trước để có baseline.
- Đọc toàn bộ component liên quan và search selector CSS trong cả hai file CSS.
- Làm một phase nhỏ, kiểm thử, review diff rồi mới sang phase kế tiếp.
