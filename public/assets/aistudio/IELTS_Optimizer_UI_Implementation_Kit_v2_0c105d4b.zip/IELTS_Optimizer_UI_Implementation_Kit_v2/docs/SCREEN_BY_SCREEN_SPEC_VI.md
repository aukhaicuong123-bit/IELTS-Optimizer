# Đặc tả chi tiết từng ngóc ngách

Ảnh tương ứng ở `references/screens/`. Đây là **visual references**, không phải spec nguồn và không phải screenshot từ production. Khi text trong ảnh không khớp code/data, ưu tiên code và nội dung hiện có.

## 01. Dashboard — `01-dashboard.png`

**Mục tiêu:** cho người học thấy hành trình, biết nhiệm vụ tiếp theo và bắt đầu học nhanh.

- Giữ sidebar hiện tại nguyên trạng.
- Main area: welcome line nhỏ; headline ngắn; nền watercolor núi/rừng/chim chỉ ở vùng hero, không phủ toàn trang.
- Learning Journey: badge rank hiện tại, XP earned, XP còn tới rank kế, % progress của rank và 6 milestone; chỉ một milestone active.
- Next Study Mission: tên task từ recommendation hiện có, kỹ năng, thời lượng nếu có nguồn, lý do chọn, CTA mở đúng route. Không hardcode “Matching Headings” cho mọi người.
- Daily timer: idle/running/paused/completed/error states; không để timer chạy đôi khi component re-render.
- Streak: dựa vào `measuredStreak`; không cộng streak từ ngày kế hoạch hoặc nghỉ.
- Skill snapshot: hiển thị đúng data sẵn có; nếu chưa có band đo, ghi “Chưa có dữ liệu”, không bịa band.
- Recent evidence: kết quả gần nhất và đường sang Error Memory/Record.
- Heatmap: dùng `ActivityHeatmapHub` hiện tại, intensity = measured minutes hoặc goal progress theo semantics đã chốt.
- Ưu tiên visual hierarchy: Journey > Next Mission > Timer/Today > Profile/Recent Evidence > Heatmap.

## 02. Onboarding / mục tiêu — `02-onboarding.png`

- Kiểm tra route/profile flow hiện tại trước; không giả định có route onboarding riêng.
- Có thể là stepper trong `profile` hoặc flow hiện hữu. Nếu tách route, cập nhật `Page`, navigation, persistence và test.
- Trường liên quan: target band, current band nếu có, daily goal, exam date tùy chọn, days off. Không bắt buộc điền thông tin tùy chọn.
- Stepper phải có active/completed/future states; validate field ở nơi nhập; nút back không làm mất giá trị.
- CTA hoàn tất lưu vào nguồn dữ liệu profile hiện tại và trả user tới dashboard.
- Chú ý label tiếng Việt, error text gắn với field, bàn phím/màn hình nhỏ.

## 03. Today / nhiệm vụ hôm nay — `03-today-missions.png`

- Route `today` hiện chưa có trong `Page`; mặc định render nhiệm vụ trong Dashboard, không link tới một route ma.
- Nhiệm vụ chính được lấy từ recommendation/plan; nhiệm vụ phụ chỉ hiển thị nếu chúng có nguồn dữ liệu thật.
- Mỗi task: skill, task name, duration nếu có, priority/difficulty nếu có, XP chỉ khi reward logic đã tồn tại, CTA mở đúng skill/task.
- Tab “Nhiệm vụ chính/khác” chỉ tạo nếu có hành vi rõ; trạng thái rỗng có CTA xây kế hoạch/đi đến kỹ năng.
- Hoàn thành task cập nhật evidence/plan hiện có, không tự cộng completion giả.

## 04. Learning Journey — `04-learning-journey.png`

- Tái sử dụng `ForumStudyTree` và assets `assets/journey/`.
- 6 rank hiện có: Người mới, Người khám phá, Người rèn luyện, Kỳ cựu, Chuyên gia, Bậc thầy IELTS. Không tự đổi ngưỡng XP nếu chưa có quyết định sản phẩm.
- Component cần nhận một state rank/XP đã thống nhất, không tự nhân lại XP độc lập ở nhiều route.
- Current milestone nêu `current`, completed có check/label; future locked thể hiện có thể/chưa thể mở.
- Đường đi dashed/curved là trang trí; milestone text và trạng thái là HTML, responsive thành scrollable path hoặc xếp lớp phù hợp nhưng không kéo vỡ toàn trang.
- Không dùng hình người, avatar hoặc nhân vật. Không hardcode progress `%` vào ảnh.

## 05. Thư viện đề thi — `05-exam-library.png`

- File route/view: `src/ExamLibraryView.tsx`, page `question-bank`.
- Header giới thiệu rõ đây là nội dung tự biên soạn mô phỏng format IELTS, không phải đề chính thức.
- Filter module `All / Academic / General Training`; search theo `title`, `code`, `volume` đúng logic hiện có.
- Thêm/chỉnh filter chỉ khi có dataset tương ứng; không hiển thị fake “recent”, “recommended” hoặc “difficulty” nếu không có metadata.
- Collection card: volume/code/title/module, cấu trúc 4 kỹ năng, thông tin duration/question count chỉ nếu đúng collection; CTA mở đúng exam và mode.
- Lưới 2–3 cột desktop, 1 cột mobile; input và filter có label, active state bằng semantic `aria-pressed`/`aria-selected`.
- Empty search có nút clear search/reset filter; loading/error nếu có async data.
- Không nhúng ảnh screenshot. Asset `exam-library.svg`, `mock-test-paper.svg`, `exam-timer.svg`, `exam-results.svg` chỉ trang trí.

## 06. Exam runner — `06-exam-runner.png`

- Simulator thật nằm trong `src/ExamLibraryView.tsx`; giữ state và luồng hiện tại.
- Thanh trên: tên đề/kỹ năng, timer thật, progress số câu và nút nộp; nếu thoát làm mất tiến độ thì confirm.
- Desktop: navigation question/passage/section và vùng nội dung/answers cân bằng. Mobile: một cột, câu hỏi chính trước, navigator có thể collapse.
- Question navigator phân biệt answered/unanswered/current/flagged bằng icon/text, không chỉ màu.
- Reading giữ passage-question split; Listening dùng audio thật và section list; Writing giữ chart stimulus/editor/task selection; Speaking giữ mic permission/recording states.
- Save/submit phải giữ behavior existing; không thay simulator bằng ảnh hoặc dựng data demo.

## 07. Exam results — `07-exam-results.png`

- Dùng dữ liệu thực từ attempt/result hiện tại; không hardcode band 6.5 hoặc bất kỳ số liệu mockup.
- Hiển thị đúng chỉ số được calculator hỗ trợ, đánh dấu band là tham khảo khi phù hợp.
- Có review câu đúng/sai, explanation/evidence nếu data cung cấp, và action `Xem lại đáp án`, `Làm lại` hoặc `Quay lại thư viện`.
- Writing/Speaking không tự tạo band nếu chưa có service/feedback tương ứng.
- Kết quả lưu đúng store/history hiện tại; retry hoặc nhấn submit lần nữa không tạo kết quả trùng.

## 08. Reading Practice — `08-reading-practice.png`

- Giữ passage content, question schema, answer selection, scoring, previous/next và retest target.
- Desktop có thể split passage/questions; mobile xếp passage trước rồi questions, không bắt cuộn ngang.
- States: loading, no passage, unanswered, selected, submitted, review, error, active retest.
- Chỉ reveal feedback/answer sau khi submit theo logic hiện tại.
- Hình sách chỉ ở header/empty state; không đặt illustration lên paragraph/câu hỏi.

## 09. Listening Practice — `09-listening-practice.png`

- Section list, audio player, progress/current time/duration, question area, transcript nếu policy/current data cho phép.
- Nút play/pause thể hiện đúng trạng thái; đổi section xử lý reset/preserve theo hành vi hiện tại.
- Không fake waveform/progress nếu audio không phát; hỗ trợ loading/no audio/error và keyboard.
- Không cho transcript lộ sai thời điểm nếu simulator đang kiểm soát disclosure.

## 10. Writing Lab — `10-writing-lab.png`

- Giữ Task 1/Task 2, chart/table stimulus, editor, draft persistence, upload/OCR và feedback flow hiện có.
- Editor là vùng nội dung lớn nhất; toolbar không được lấn át bài viết.
- AI loading: disable submit đúng lúc, giữ bản nháp. API/OCR lỗi: báo rõ và cho retry, không xóa text.
- Rubric card chỉ render criteria/score thực sự được trả về; không tạo graph/score giả.
- Mobile: editor full width, feedback xếp phía dưới; keyboard/focus/scroll không làm mất con trỏ.

## 11. Speaking Practice — `11-speaking-practice.png`

- Không có người hoặc chân dung. Dùng microphone/waveform/landscape nhẹ.
- Part 1/2/3 selector, prompt/cue card, recording control, timer và feedback phải lấy từ state hiện có.
- States: ready, requesting permission, recording, processing, saved, permission denied, unsupported, error.
- Chỉ hỏi quyền mic khi user chủ động bắt đầu; có fallback nếu browser không hỗ trợ.
- Không hiển thị AI band/feedback khi không có pipeline feedback thật.

## 12. Vocabulary Hub — `12-vocabulary-hub.png`

- Giữ topic/category/search, flashcard vs quiz, pronunciation/audio, know/review actions.
- Nguồn known words hiện có: localStorage `ielts-optimizer-vocab-known`; không đổi key hoặc format trong redesign.
- Khi mark known, persist trước/sau theo thứ tự an toàn; idempotent chống cộng XP trùng. Unmark cần tính lại progress/rank theo quy tắc hiện hữu.
- Empty search cần clear filters; không đặt minh họa lên card word làm giảm khả năng đọc.

## 13. Grammar Hub — `13-grammar-hub.png`

- Giữ CEFR/topic filters, search, rule expand/collapse, examples, quiz answers, feedback và submissions/errors.
- XP/complete phải gắn với sự kiện completion thật, chống duplicate submit/re-render.
- Audit nguồn `completedGrammarCount` và `s.submissions`; không tính hai nguồn chồng nhau hoặc làm rank reset khi chuyển trang.
- Trạng thái đúng/sai kèm icon/text; trạng thái mở rộng có keyboard affordance.

## 14. Error Memory / Retest — `14-error-memory.png`

- Mapping tới `src/App.tsx`, `src/domain.ts`, `src/readingEngine.ts` và route `errors`.
- Hiển thị trạng thái domain thật: open/resolved/insufficient evidence; không coi “đã thử retest” tương đương “đã mastery”.
- Giữ occurrence identity khi nhiều lần sai cùng difficulty; không gộp các occurrence độc lập.
- Filter theo skill/state/date chỉ khi data hỗ trợ. Retest chọn nội dung tương đương dựa trên engine; nếu không chứng minh được equivalence thì fail closed.
- Empty state trung tính, mô tả bước tiếp theo; không biến mọi lỗi thành cảnh báo đỏ.

## 15. Analytics / Heatmap — `15-analytics.png`

- `ActivityHeatmapHub` và domain metrics là nguồn dữ liệu thật.
- Metric cards phải định nghĩa được tử/mẫu, thời gian đo và đơn vị; loại bỏ metric chưa có data.
- Heatmap thể hiện thời gian/hoạt động học và goal, không tự suy luận mastery.
- Planned rest days không bị tô là failure. Streak dựa trên session rules hiện tại.
- Biểu đồ có title, axis/legend/units và accessible text summary; mobile xếp từng chart theo chiều dọc.

## 16. Profile / Settings — `16-profile-settings.png`

- Tái sử dụng `Profile` hiện có trong `src/App.tsx`; các mục Settings không tồn tại route độc lập thì làm thành panel/section thay vì link giả.
- Trường target band/current level/exam date/daily goal/days off giữ validation và persistence hiện tại.
- Profile không dùng hình chân dung người; dùng icon, rank badge hoặc minh họa phong cảnh.
- Cảnh báo khi reset/clear store; không thay behavior clearStore hoặc dữ liệu localStorage ngoài phạm vi cần thiết.

## 17. Component Library — `17-component-library.png`

- Chuẩn hóa button, card, chips, progress bar, band selector, timer, streak, task card, list row, filter/tabs, input, modal, toast, pagination và focus.
- Tạo token/shared CSS theo scale; không sao chép inline styles từ từng screen thành nhiều phiên bản.
- Mỗi component có default/hover/focus/active/disabled/loading/error khi applicable.
- Tránh tạo abstraction quá sớm: nếu chỉ dùng một nơi và chưa cần variability, ưu tiên style/component rõ ràng thay vì framework UI riêng.

## 18. Empty / Loading / Responsive — `18-empty-loading-responsive.png`

- Empty: có icon/illustration nhẹ, nói rõ vì sao chưa có dữ liệu và một CTA hữu ích.
- Loading: skeleton hình học gần cấu trúc card; không tạo spinner vô hạn khi request đã lỗi.
- Error: thông báo có thể hành động, không để exception thô trong UI.
- Success: thông báo rõ tác động thật, XP chỉ hiện nếu domain đã ghi nhận reward.
- Responsive: test 1440/1024/768/390/320 px; giữ sidebar/drawer behavior hiện tại, không horizontal overflow.

## Quy tắc chung cho toàn bộ màn hình

- Ảnh là reference để định hướng bố cục; không sử dụng file `references/screens/*.png` làm background/DOM image.
- Render text/data/buttons/cards/charts bằng React/CSS.
- Không có nhân vật người hoặc avatar người do AI sinh.
- Giữ nội dung tiếng Việt dễ hiểu; không hardcode số của mockup.
- Không tự thêm route/CTA chưa có chức năng; mọi nút phải làm đúng điều nó ghi.
