# Phase 0 — Audit trước khi sửa

Đọc `START_HERE_FOR_AGENT.txt`, `docs/REPO_MAP_VI.md`, `AGENT_BUILD_GUIDE_VI.md`, `docs/DESIGN_SYSTEM_VI.md` và xem reference index.

Trong repository `aukhaicuong123-bit/IELTS-Optimizer`:
1. Kiểm tra branch, `git status`, uncommitted changes; không overwrite chúng.
2. Chạy `npm test` và `npm run build`, ghi kết quả baseline nguyên văn.
3. Xác minh thật route/component/CSS của Dashboard, `question-bank`/`ExamLibraryView`, practice skills, Vocabulary/Grammar, Error Memory, Analytics/Profile.
4. Tìm nguồn sự thật của XP/rank, streak, heatmap, recommendation, timer, scoring và persistent state. Đặc biệt audit consistency giữa `ForumStudyTree`, Vocabulary và Grammar; không tự sửa logic trong audit phase.
5. Tìm selector CSS ảnh hưởng rộng trong `styles.css` và `extra.css`; xác định mobile nav behavior và Vite base path.
6. Báo cáo findings + phase plan ngắn gọn và chờ chỉ thị trước khi code.

Không sửa code ở phase này. Không tạo metrics hoặc route mới.
