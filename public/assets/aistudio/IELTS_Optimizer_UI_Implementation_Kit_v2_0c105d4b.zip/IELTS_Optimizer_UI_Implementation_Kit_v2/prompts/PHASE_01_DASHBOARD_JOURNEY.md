# Phase 1 — Dashboard + Learning Journey

Dùng `references/screens/01-dashboard.png`, `03-today-missions.png`, `04-learning-journey.png` và tài liệu `docs/SCREEN_BY_SCREEN_SPEC_VI.md`.

Redesign Dashboard nhưng giữ nguyên sidebar. Reuse `ForumStudyTree`, `DashboardTimerCard`, `LearnerProfileCard`, `RecentEvidence`, `ActivityHeatmapHub` và recommendation engine hiện tại khi phù hợp. Hành trình và nhiệm vụ tiếp theo là ưu tiên thị giác đầu tiên. XP/rank/timer/heatmap phải dựa trên dữ liệu và domain logic thật.

Không tạo route `today`/`journey` ma. Không hardcode progress hoặc reward. Không thay đổi persistence schema. Dùng asset riêng, tuyệt đối không nhúng screenshot reference. Kiểm thử desktop/mobile, timer transitions, heatmap update, XP consistency. Chạy test/build và báo diff/result.
