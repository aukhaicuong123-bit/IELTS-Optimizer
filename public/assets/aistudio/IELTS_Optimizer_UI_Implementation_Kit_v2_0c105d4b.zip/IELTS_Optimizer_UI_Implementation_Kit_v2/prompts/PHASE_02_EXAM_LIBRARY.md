# Phase 2 — Thư viện đề thi + simulator

Dùng reference `05-exam-library.png`, `06-exam-runner.png`, `07-exam-results.png` và đọc `docs/EXAM_LIBRARY_UI_SPEC_VI.md`.

Làm việc chủ yếu trong `src/ExamLibraryView.tsx`, dựa vào `IELTS_EXAM_COLLECTIONS` và calculator/helper hiện có. Làm rõ search/filter, module Academic/General Training, cards, metadata, CTA, empty result, exam runner và result review. Giữ nguyên mode Reading/Listening/Writing/Speaking, answer state, timer, submit, scoring, store/history và disclaimer đề tự biên soạn không phải đề chính thức IELTS.

Không nhúng ảnh mockup, không fake metadata, không thay nội dung simulator bằng ảnh. Asset library/reference URL phải tương thích base path GitHub Pages. Test CTA mỗi skill, exit/back, persistence, all filters, mobile và no-results. Chạy test/build.
