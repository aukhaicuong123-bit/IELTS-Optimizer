# Phase 3 — Reading, Listening, Writing, Speaking

Dùng refs `08-reading-practice.png` đến `11-speaking-practice.png`. Audit từng component/route trước khi thay CSS.

Giữ question model, answer state, previous/next, scoring/retest cho Reading; audio real/player/transcript policy cho Listening; task selector, chart stimulus, draft/OCR/AI-feedback states cho Writing; microphone permissions/recording/timer states cho Speaking. Không chèn người, không giả audio/waveform/band. Draft phải được giữ nếu AI/API/OCR lỗi.

Thực hiện theo từng kỹ năng, kiểm tra bàn phím và mobile, không refactor đồng thời cả bốn page. Chạy test/build mỗi lần.
