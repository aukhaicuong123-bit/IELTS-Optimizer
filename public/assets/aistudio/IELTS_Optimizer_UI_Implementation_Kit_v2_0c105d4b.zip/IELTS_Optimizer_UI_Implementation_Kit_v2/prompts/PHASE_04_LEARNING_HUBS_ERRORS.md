# Phase 4 — Vocabulary, Grammar, Error Memory

Dùng refs `12-vocabulary-hub.png`, `13-grammar-hub.png`, `14-error-memory.png` cùng specs.

Giữ topic/filter/search, flashcard/quiz, pronunciation và localStorage key `ielts-optimizer-vocab-known`; giữ grammar rules/quiz/submission/error behavior; Error Memory phải dùng domain/reading engine state. Audit and preserve occurrence identity/equivalence; “đã làm retest” không đồng nghĩa “đã mastery”. XP idempotent, không cộng trùng, không reset khi chuyển route.

Không thay content bằng ảnh; kiểm thử reload, duplicate clicks, filter-empty, wrong/correct retest, multiple occurrences và cross-route rank consistency. Chạy test/build.
