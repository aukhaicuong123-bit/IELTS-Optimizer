# Phase 5 — Analytics, Profile, states, responsive final pass

Dùng refs `15-analytics.png`, `16-profile-settings.png`, `17-component-library.png`, `18-empty-loading-responsive.png`.

Rà lại charts/heatmap units, streak, profile/settings, save/reset dialogs, toast, empty/loading/error/success, responsive và accessibility. Không tạo route cho Settings/Analytics nếu route không có trong `Page`; dùng section/view hiện có hoặc triển khai route có type/router/test rõ.

Kiểm tra 1440/1024/768/390/320px, contrast/focus, keyboard, `prefers-reduced-motion`, overflow, base path; chạy full `npm test` + `npm run build`; review git diff và ghi rõ mọi regression/việc chưa verify.
