# Screen Reference Index

Ảnh tham chiếu để agent hiểu bố cục. Không nhúng các ảnh này vào website; dựng giao diện bằng React/CSS. Các crop có thể chứa chữ minh họa chưa hoàn hảo. Source code/dữ liệu thật mới là nguồn sự thật.

## 01 · Dashboard
- File: `references/screens/01-dashboard.png`
- Dùng để tham chiếu: Hành trình, rank, nhiệm vụ tiếp theo, timer, streak, tiến độ kỹ năng.

## 02 · Onboarding / Mục tiêu
- File: `references/screens/02-onboarding.png`
- Dùng để tham chiếu: Các bước đặt mục tiêu, band target, thời lượng học và tiếp tục.

## 03 · Today / Nhiệm vụ
- File: `references/screens/03-today-missions.png`
- Dùng để tham chiếu: Nhiệm vụ ưu tiên, nhiệm vụ phụ, thời lượng và CTA.

## 04 · Learning Journey
- File: `references/screens/04-learning-journey.png`
- Dùng để tham chiếu: Bản đồ hành trình, sáu rank, tiến độ cấp hiện tại.

## 05 · Thư viện đề thi
- File: `references/screens/05-exam-library.png`
- Dùng để tham chiếu: Search, module filter, bộ lọc, collection cards và bắt đầu đề.

## 06 · Giao diện làm đề
- File: `references/screens/06-exam-runner.png`
- Dùng để tham chiếu: Timer, câu hỏi, question navigator, đánh dấu và nộp bài.

## 07 · Kết quả đề thi
- File: `references/screens/07-exam-results.png`
- Dùng để tham chiếu: Band tham khảo theo kỹ năng, tổng quan và xem phân tích.

## 08 · Reading Practice
- File: `references/screens/08-reading-practice.png`
- Dùng để tham chiếu: Danh sách bài/passage, câu hỏi, lựa chọn đáp án và điều hướng.

## 09 · Listening Practice
- File: `references/screens/09-listening-practice.png`
- Dùng để tham chiếu: Danh sách section, audio controls, câu hỏi và transcript.

## 10 · Writing Lab
- File: `references/screens/10-writing-lab.png`
- Dùng để tham chiếu: Task picker, editor, lưu nháp, gửi bài và feedback.

## 11 · Speaking Practice
- File: `references/screens/11-speaking-practice.png`
- Dùng để tham chiếu: Prompt/Part, microphone, waveform/trạng thái thu âm, gợi ý.

## 12 · Vocabulary Hub
- File: `references/screens/12-vocabulary-hub.png`
- Dùng để tham chiếu: Search, tabs, filters, flashcard, pronunciation và trạng thái nhớ.

## 13 · Grammar Hub
- File: `references/screens/13-grammar-hub.png`
- Dùng để tham chiếu: Rule list, level, tiến độ, mini-quiz và expand/collapse.

## 14 · Error Memory / Retest
- File: `references/screens/14-error-memory.png`
- Dùng để tham chiếu: Lỗi theo skill, trạng thái xử lý, bằng chứng, hành động retest.

## 15 · Analytics & Heatmap
- File: `references/screens/15-analytics.png`
- Dùng để tham chiếu: Thời gian học, XP, heatmap, skill breakdown và xu hướng.

## 16 · Profile / Settings
- File: `references/screens/16-profile-settings.png`
- Dùng để tham chiếu: Hồ sơ, mục tiêu, cài đặt học tập và tùy chọn giao diện.

## 17 · Component Library
- File: `references/screens/17-component-library.png`
- Dùng để tham chiếu: Nút, card, progress, chip, field, icons, colors và type scale.

## 18 · Empty / Loading / Responsive
- File: `references/screens/18-empty-loading-responsive.png`
- Dùng để tham chiếu: Empty states, loading states và ý tưởng responsive.
